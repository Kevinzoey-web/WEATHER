package com.translator.ventuskyweb

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient

class secondActivity : AppCompatActivity() {
    private val webview:WebView?=null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_second)
        title = "VENTUSKY WEATHER"
        val webview = findViewById<WebView>(R.id.webView)
        webview?.webViewClient = WebViewClient()
        webview?.loadUrl("https://www.ventusky.com")
        val webSettings = webview.settings

        webSettings.javaScriptEnabled = true

    }

    override fun onBackPressed() {
        if(webview!!.canGoBack()){webview.goBack()}
        else {
        super.onBackPressed()
    }
}
}
